import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  boolean,
} from "drizzle-orm/pg-core";

export const studentAccounts = pgTable("student_accounts", {
  id: serial("id").primaryKey(),
  studentCode: text("student_code").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  displayName: text("display_name").notNull(),
  portalUrl: text("portal_url").notNull().default("https://sprixportal.jp/"),
  aiModel: text("ai_model").notNull().default("qureo-neural-v4"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastLoginAt: timestamp("last_login_at").defaultNow().notNull(),
});

export const chapterProgress = pgTable("chapter_progress", {
  id: serial("id").primaryKey(),
  studentCode: text("student_code").notNull(),
  chapterNumber: integer("chapter_number").notNull(),
  status: text("status").notNull().default("analyzed"), // 'pending' | 'in_progress' | 'analyzed'
  accuracy: integer("accuracy").notNull().default(100),
  solvedExercises: integer("solved_exercises").notNull().default(10),
  totalExercises: integer("total_exercises").notNull().default(10),
  executionTimeMs: integer("execution_time_ms").notNull().default(420),
  aiNotes: text("ai_notes"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const analysisRuns = pgTable("analysis_runs", {
  id: serial("id").primaryKey(),
  studentCode: text("student_code").notNull(),
  runType: text("run_type").notNull().default("full_42_chapters"),
  chaptersAnalyzed: integer("chapters_analyzed").notNull().default(42),
  averageAccuracy: integer("average_accuracy").notNull().default(100),
  githubExportReady: boolean("github_export_ready").notNull().default(true),
  summaryLog: text("summary_log").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
