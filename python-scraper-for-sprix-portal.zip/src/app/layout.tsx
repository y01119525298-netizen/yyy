import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "محلل منصة كيرو الشامل (42 فصلاً) بالبايثون | QUREO 42-Chapter Python Analyzer",
  description:
    "منظومة بايثون متكاملة لتحليل الـ 42 فصلاً كاملة لمنصة كيرو (sprixportal.jp) بدقة 100% مع تسجيل الدخول بالكود وكلمة المرور وتوليد ملفات جاهزة للرفع على GitHub.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-slate-950 text-slate-100 antialiased selection:bg-emerald-500 selection:text-slate-950">
        {children}
      </body>
    </html>
  );
}
